import React, {useContext} from 'react'
import cartimg from '../src/img/download.png';
import CartStoreItems from '../src/store/cart-items' 

export default function Header() {


  const cartStoreItemCtx = useContext(CartStoreItems);
  //const countCart = cartStoreItemCtx.cartItemInCart.reduce(myFunc);
/*useEffect(()=>{
  console.log(cartStoreItemCtx.cartItemInCart);
  console.log(cartStoreItemCtx.totalAmount);
}, [cartStoreItemCtx.cartItemInCart]);
 */
  

  return (
    <div className='headertop'>
          <div className='cartshowbox'>
             <div className='cartimage'><img src={cartimg} /></div>
             <div className='cartcount'>{cartStoreItemCtx.cartItemInCart.length}</div>
          </div>
    </div>
  )
}
