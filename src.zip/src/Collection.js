import React, {useContext} from 'react'
import cartStoreItems from './store/cart-items';

export default function Collection() {
 
  const cartStoreItemCtx = useContext(cartStoreItems);

    const collec = [
        {id: 1, primg: 'https://i.pinimg.com/736x/b0/eb/f7/b0ebf7e1b39d95aee841c2985581d6dc.jpg', prname: 'Product 1', cat: 'cat 1', pric: '20.23' },
        {id: 2, primg: 'https://i.pinimg.com/736x/09/c5/65/09c565fa4bd558445fe8a88daf158aa8.jpg', prname: 'Product 2', cat: 'cat 2', pric: '10.23' },
        {id: 3, primg: 'https://i.pinimg.com/736x/52/ff/42/52ff42f0debd210e512991a637cab45e.jpg', prname: 'Product 3', cat: 'cat 4', pric: '12.00' },
        {id: 4, primg: 'https://i.pinimg.com/736x/2b/d3/6f/2bd36f0cb13cfd602de8619bd1a4c38c.jpg', prname: 'Product 4', cat: 'cat 5', pric: '9.00' },                   
       ];

       const probuid = collec.map(
        collect =>
        <div className="prdlist" key={collect.id} >
            <div className='prwrap'>
            <img src={collect.primg} />
            <span className="prnam pm">{collect.prname}</span>
            <span className="prcat pm">{collect.cat}</span>
            <span className="prpric pm">$ {collect.pric} </span>
            <span> <button id={`pr${collect.id}`} data-prname={collect.prname} data-prid={collect.id} data-price={collect.pric} data-cat={collect.cat} className="pmcl" onClick={cartStoreItemCtx.addCartItems}>Add To Cart</button> </span>
        </div>
        </div>
        );

  return (
    <div className="colectionlist">
    {probuid} 
  </div>
  )
}
