import './App.css';
import Collection from './Collection';
import Header from './Header';
import CartItems from './CartItems';
import CartStoreItems from '../src/store/cart-items'
import { useState } from 'react';

function App() {

  const cartempty =[];
  const [CartItemInCartState, setCartItemInCartState] = useState(cartempty);
  const [totalAmountState, settotalAmountState] = useState(0);

  const addCartItems =(event)=>{
    const productName = event.target.dataset.prname;
    const prid = event.target.dataset.prid;
    const price = event.target.dataset.price;
    //console.log(productName);

   const cartCheck = CartItemInCartState.some(item => item.prid === prid);
   //console.log(cartCheck);
   if(cartCheck === true){

    const objIndex = CartItemInCartState.findIndex((obj => obj.prid == prid));
    CartItemInCartState[objIndex].pqty = +(CartItemInCartState[objIndex].pqty) + +1;
    CartItemInCartState[objIndex].subTotalAmount =  +CartItemInCartState[objIndex].pqty * +(CartItemInCartState[objIndex].price);

    setCartItemInCartState((prev)=>{
      return [...prev];
    });

    /*const updatedQuty = CartItemInCartState.reduce((prevValue, currentValue)=>{
      return +prevValue.pqty + +currentValue.pqty;
    });*/

    const updatedAmount = CartItemInCartState.reduce((prevValue, currentValue)=>{
     return +prevValue + +currentValue.subTotalAmount;
    }, 0);

    //console.log(updatedAmount);

    settotalAmountState(updatedAmount);
  
   }else{

    const cartdata = {
      prid: prid,
      productName: productName, 
      price: +price,
      pqty: 1,
      subTotalAmount: +price
   };

   setCartItemInCartState((prev)=>{
     return [...prev, cartdata];
   });

   const totalamountofrcurrent = +price + +totalAmountState;
   settotalAmountState(totalamountofrcurrent);

   }


  }


  return (
    <div className="App">

      <CartStoreItems.Provider value={{
         cartItemInCart: CartItemInCartState,
         totalAmount: totalAmountState,
         addCartItems: addCartItems,
         removeCartItems: (id)=>{}
      }}>
            <Header />
            <CartItems />
            <Collection /> 
      </CartStoreItems.Provider>
    </div>
  );
}

export default App;
