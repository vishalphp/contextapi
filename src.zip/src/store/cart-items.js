import React from 'react'

const cartStoreItems = React.createContext({
    cartItemInCart: [],
    totalAmount: 0,
    addCartItems: (event)=>{},
    removeCartItems: (id)=>{} 
});

export default cartStoreItems;