import React, {useContext} from 'react'
import CartStoreItems from '../src/store/cart-items' 

export default function CartItems() {

  const cartStoreItemCtx = useContext(CartStoreItems);

  const cartStoreMapItems = cartStoreItemCtx.cartItemInCart.map(items=> {
     return  <div className='wrapli'><div className='comanprduc'>{items.productName}</div><div className='comanprduc'>{items.price}</div><div className='comanprduc'>{items.pqty}</div><div className='comanprduc'>{items.subTotalAmount}</div></div>;
  });

  return (
    <div className='cartstoreboxborder'>

       <div className='wrapheader'>
          <div className='titlepr'>Title</div>
          <div className='pricepr'>Price</div> 
          <div className='qtypr'>Qty</div>  
          <div className='subtotal'>Sub Total</div> 
        </div> 

        <div className='itemsdata'>
            {cartStoreMapItems}
        </div>    

        <div className='wrapamount'>
          <div>Total Amount</div>
          <div>$ {cartStoreItemCtx.totalAmount}</div>
        </div>

    </div>
  )
}
